# created by Nilay
from django.http import HttpResponse
from django.shortcuts import render
def hello(request):
    return render(request,'insex.html')

def about(request):
    return HttpResponse('about')

def cap(request):
    return HttpResponse('Capitalise')

def count(request):
    return HttpResponse('count')

def Rspace(request):
    return HttpResponse('Remove Space')
def RemovePunctuation(request):
    return HttpResponse('Remove Space')

def removeword(Enteredtext):
    punclist=['.',',',':',';','?','(',')','[',']','"','!','_','-','/','<','>','*']
    word=''
    for i in Enteredtext:
        if i not in punclist:
            word=word+i
    print(word)
    return word

def capital(x):
    return x.upper()
def analyze(request):
    perpousText=''
    analysed=''
    Enteredtext=(request.GET.get('text','default'))
    removepunc=(request.GET.get('RemovePunctuation','off'))
    cap=(request.GET.get('Capitalise','off'))
    countofWord=request.GET.get('Count','off')
    print('This is ' +countofWord)
    if cap=='off' and countofWord=='off' and removepunc!='off':
        analysed=removeword(Enteredtext)
        perpousText='Remove Punctuations'
    elif cap!='off' and countofWord=='off' and removepunc=='off':
        analysed=capital(Enteredtext)
        print('after cap '+analysed)
        perpousText='Capitalise'
    elif cap=='off' and countofWord!='off' and removepunc=='off':
        xword=Enteredtext.strip()
        print(xword)
        analysed=str(len(xword))
        print(analysed)
        perpousText='Count'
    elif cap=='off' and countofWord=='off' and removepunc=='off':
        return HttpResponse('ERROR')
    else:
        return HttpResponse('ERROR')



    params={'purpose':perpousText,'analyzed_text':analysed}
    return render(request,'analyze.html',params)